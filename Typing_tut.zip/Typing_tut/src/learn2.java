

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class learn2 extends JFrame {

	private JPanel contentPane;
	private String info,info1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					learn2 frame = new learn2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public learn2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 604);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAimForAccuracy = new JLabel("Aim for accuracy rather than speed.");
		lblAimForAccuracy.setFont(new Font("Calibri", Font.BOLD, 20));
		lblAimForAccuracy.setBounds(23, 10, 329, 42);
		contentPane.add(lblAimForAccuracy);
		
		info= "It does not matter how fast you type if you have to go back and fix all your mistakes. Fixing mistakes takes more time than it does to just slow down and take the time you need to type accurately. Fast typing depends on developing precision muscle memory. Allowing yourself to type incorrectly will actually reinforce your bad habits and common mistakes! Slow your typing pace until you can attain 100% accuracy. If you come across a difficult word, slow down further to type it properly. Develop good habits and speed will be your reward.";
		info1 = "Mastering typing skills takes training and practice. Practice on a regular schedule, 10 minutes to an hour per session, depending on your energy and focus level. As Vince Lombardi said, �Practice doesn�t make perfect, perfect practice makes perfect,� so it is important that you practice at a time and place where you can maintain focus and accuracy. ";
		JTextArea textArea = new JTextArea(info);
		textArea.setFont(new Font("Calibri", Font.PLAIN, 15));
		textArea.setBounds(33, 62, 692, 130);
		textArea.setFocusable(false);
		textArea.setBackground(null);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		contentPane.add(textArea);
		
		JLabel lblPracticeTypingExercises = new JLabel("Practice typing exercises regularly.");
		lblPracticeTypingExercises.setFont(new Font("Calibri", Font.BOLD, 20));
		lblPracticeTypingExercises.setBounds(402, 230, 310, 42);
		contentPane.add(lblPracticeTypingExercises);
		
		JTextArea textArea_1 = new JTextArea(info1);
		textArea_1.setFont(new Font("Calibri", Font.PLAIN, 15));
		textArea_1.setBounds(367, 298, 419, 146);
		textArea_1.setFocusable(false);
		textArea_1.setBackground(null);
		textArea_1.setLineWrap(true);
		textArea_1.setWrapStyleWord(true);
		contentPane.add(textArea_1);
		
		JLabel label = new JLabel("");
		Image img8 = new ImageIcon(this.getClass().getResource("8.png")).getImage();
		label.setIcon(new ImageIcon(img8));
		label.setBounds(10, 219, 340, 260);
		contentPane.add(label);
		
		JButton btnStartLearning = new JButton("Start Learning");
		btnStartLearning.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI gui = new GUI();
				gui.setVisible(true);
				gui.setLocationRelativeTo(null);
			}
		});
		btnStartLearning.setFont(new Font("Calibri", Font.BOLD, 25));
		btnStartLearning.setBounds(549, 490, 209, 48);
		contentPane.add(btnStartLearning);
		
		JTextPane txtpnNote = new JTextPane();
		txtpnNote.setFont(new Font("Calibri", Font.BOLD, 20));
		txtpnNote.setText("Note -- >  Learn the Keyboard");
		txtpnNote.setFocusable(false);
		txtpnNote.setBackground(null);
		txtpnNote.setBounds(10, 501, 411, 37);
		contentPane.add(txtpnNote);
	}
}
