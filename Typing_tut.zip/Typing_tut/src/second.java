

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class second extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					second frame = new second();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public second() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 802, 604);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnHelp = new JMenu("Help");
		mnHelp.setFont(new Font("Calibri", Font.BOLD, 20));
		mnHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				
			}
		});
		menuBar.add(mnHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		
		JButton btnBasics = new JButton("Start Typing");
		btnBasics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GUI gui = new GUI();
				gui.setVisible(true);
				gui.setLocationRelativeTo(null);
			}
		});
		btnBasics.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 40));
		btnBasics.setBounds(10, 407, 246, 67);
		contentPane.add(btnBasics);
		
		JButton btnAdvanced = new JButton("Learn Typing");
		btnAdvanced.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				learn l1 = new learn();
				l1.setVisible(true);
				l1.setLocationRelativeTo(null);
				
			}
		});
		btnAdvanced.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 40));
		btnAdvanced.setBounds(274, 407, 260, 67);
		contentPane.add(btnAdvanced);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnExit.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 40));
		btnExit.setBounds(552, 408, 226, 64);
		contentPane.add(btnExit);
		
		JLabel label = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("4.gif")).getImage();
		label.setIcon(new ImageIcon(img1));
		label.setBounds(175, 110, 400, 241);
		contentPane.add(label);
		
		JLabel lblPlaceYourHands = new JLabel("Place your Hands like this before you start");
		lblPlaceYourHands.setFont(new Font("Calibri", Font.BOLD, 20));
		lblPlaceYourHands.setBounds(75, 48, 597, 31);
		contentPane.add(lblPlaceYourHands);
		
		JMenuItem mntmLearnTyping = new JMenuItem("Learn Typing");
		mntmLearnTyping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				learn l1 = new learn();
				l1.setVisible(true);
				l1.setLocationRelativeTo(null);
			}
		});
		mntmLearnTyping.setFont(new Font("Calibri", Font.PLAIN, 15));
		mnHelp.add(mntmLearnTyping);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				About l1 = new About();
				l1.setVisible(true);
				l1.setLocationRelativeTo(null);
			}
		});
		mntmAbout.setFont(new Font("Calibri", Font.PLAIN, 15));
		mnHelp.add(mntmAbout);
	
	}

}
