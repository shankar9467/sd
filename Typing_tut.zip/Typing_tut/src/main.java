

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main window = new main();
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 604);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTypingTutor = new JLabel("Typing Tutor");
		lblTypingTutor.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 80));
		lblTypingTutor.setBounds(158, 51, 514, 113);
		frame.getContentPane().add(lblTypingTutor);
		
		JButton btnNewButton = new JButton("Start Learning");
		btnNewButton.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 40));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				second window1 = new second();
				window1.setVisible(true);
				window1.setLocationRelativeTo(null);
			}
		});
		btnNewButton.setBounds(414, 215, 299, 74);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton_1.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 40));
		btnNewButton_1.setBounds(414, 348, 299, 64);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("2.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(49, 213, 299, 199);
		frame.getContentPane().add(lblNewLabel);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnHelp = new JMenu("Help");

		mnHelp.setFont(new Font("Calibri", Font.BOLD, 20));
		menuBar.add(mnHelp);
		
		JMenuItem mntmLearnTyping = new JMenuItem("Learn Typing");
		mntmLearnTyping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				learn l1 = new learn();
				l1.setVisible(true);
				l1.setLocationRelativeTo(null);
			}
		});
		mntmLearnTyping.setFont(new Font("Calibri", Font.PLAIN, 15));
		mnHelp.add(mntmLearnTyping);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				About l1 = new About();
				l1.setVisible(true);
				l1.setLocationRelativeTo(null);
			}
		});
		mntmAbout.setFont(new Font("Calibri", Font.PLAIN, 15));
		mnHelp.add(mntmAbout);
		
	}
}
