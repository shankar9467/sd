

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class learn extends JFrame {

	private JPanel contentPane;
	private JTextArea promptBox;
	private String info1,info2;
	private JLabel lblNewLabel_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					learn frame = new learn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public learn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 804, 601);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Home Row Position :\r\n");
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel.setBounds(34, 10, 219, 33);
		contentPane.add(lblNewLabel);
			
	    info1 = "Curve your fingers a little and put them on the ASDF and JKL; keys which are located in the middle row of the letter keys. This row is called HOME ROW because you always start from these keys and always return to them. F and J keys under your index fingers should have a raised line on them to aide in finding these keys without looking.";
		info2 = "The color-coded keyboard under lesson input field will help you to understand which finger should press each key.\r\n" + 
				"\r\n" + 
				"Hit keys only with the fingers for which they have been reserved.\r\n" + 
				"Always return to the starting position of the fingers \"ASDF � JKL;\".\r\n" + 
				"When typing, imagine the location of the symbol on the keyboard.\r\n" + 
				"Establish and maintain a rhythm while typing. Your keystrokes should come at equal intervals.\r\n" + 
				"The SHIFT key is always pressed by the pinky finger opposite to the one hitting the other key.\r\n" + 
				"Use the thumb of whichever hand is more convenient for you to press the Space bar.";
	    promptBox = new JTextArea(info1);
	    promptBox.setFont(new Font("Calibri", Font.PLAIN, 15));
		promptBox.setFocusable(false);
		promptBox.setBackground(null);
		promptBox.setBounds(44, 53, 315, 137);
		promptBox.setLineWrap(true);
		promptBox.setWrapStyleWord(true);
		contentPane.add(promptBox);
		
		promptBox.setColumns(10);
		
		lblNewLabel_1 = new JLabel("");
		Image img6 = new ImageIcon(this.getClass().getResource("6.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img6));
		lblNewLabel_1.setBounds(440, 21, 340, 171);
		contentPane.add(lblNewLabel_1);
		
		JTextArea textArea = new JTextArea(info2);
		textArea.setFont(new Font("Calibri", Font.PLAIN, 15));
		textArea.setBounds(389, 237, 391, 304);
		textArea.setFocusable(false);
		textArea.setBackground(null);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		contentPane.add(textArea);
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image img7 = new ImageIcon(this.getClass().getResource("7.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img7));
		lblNewLabel_2.setBounds(24, 324, 355, 209);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u041Aeyboard scheme :");
		lblNewLabel_3.setFont(new Font("Calibri", Font.BOLD, 20));
		lblNewLabel_3.setBounds(34, 237, 270, 49);
		contentPane.add(lblNewLabel_3);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 231, 770, -7);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("Next -->");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				learn2 l2 = new learn2();
				l2.setVisible(true);
				l2.setLocationRelativeTo(null);
				
			}
		});
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 15));
		btnNewButton.setBounds(665, 531, 92, 23);
		contentPane.add(btnNewButton);
		
		
    
        

		
		
	}
}
