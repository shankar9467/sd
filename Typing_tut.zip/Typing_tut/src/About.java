

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;

public class About extends JFrame {

	private JPanel contentPane;
	private String info;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					About frame = new About();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public About() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 803, 605);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAboutTypingTutor = new JLabel("About Typing Tutor :");
		lblAboutTypingTutor.setFont(new Font("Calibri", Font.BOLD, 25));
		lblAboutTypingTutor.setBounds(40, 84, 299, 67);
		contentPane.add(lblAboutTypingTutor);
		
		info  = "This is a Typing Tutor made to improve user�s typing skills. This is made using Java and Window Builder Functionality in java to make Graphical User Interface for typing tutor to get a great learning experience"
				+ "It has a feature of displaying your typing speed , in the form of words per minute , and at the end it also displays your accuracy , which you can try to improve ";
		JTextArea textArea = new JTextArea(info);
		textArea.setFont(new Font("Calibri", Font.PLAIN, 20));
		textArea.setBounds(40, 176, 672, 285);
		textArea.setFocusable(false);
		textArea.setBackground(null);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		contentPane.add(textArea);
	}
}
